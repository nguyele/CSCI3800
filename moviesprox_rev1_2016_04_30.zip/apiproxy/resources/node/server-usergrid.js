var argo = require('argo');
var express = require('express');
var async = require('async');

var app = express();

var proxy = argo()
    .target('https://api.usergrid.com/quyennguyenmai/HW4/movies')
    .build();

var usergrid = require('usergrid');

app.use(express.bodyParser());


var client = new usergrid.client({
    orgName:'quyennguyenmai',
    appName:'HW4',
});


var rootTemplate = {
	'HW4' : {
		'href' : './HW4'
	}
};

app.get('/', function(req, resp) {
	resp.jsonp(rootTemplate);
});


app.get('/movies', function(req, res) {	
		getMovies(req, res);
});

function getMovies(req, res) {
	client.createCollection({
		type : 'movies'
	}, function(err, movies) {
		if (err) {
			res.jsonp(500, {
				'error' : JSON.stringify(err)
			});
			return;
		}

		var emps = [];
		while (movies.hasNextEntity()) {
			var emp = movies.getNextEntity().get();
			var e = {
				'name' : emp.name,
				'cast' : emp.cast,
				'year released' : emp.yearReleased
			};
			emps.push(e);
		}
		res.jsonp(emps);
	});
}


app.post('/', function(req, res) {
	if (!req.is('json')) {
		res.jsonp(400, {
			error : 'Missing'
		});
		return;
	}

	var b = req.body;
	var e = {
		'name' : b.name,
		'cast' : b.cast,
		'year released' : emp.yearReleased
	};

	if ((e.name === undefined) || (e.yearReleased === undefined)
			|| (e.cast === undefined)) {
		res.jsonp(400, {
			error : 'Undefined'
		});
		return;
	}

	createMovie(e, req, res);
});

function createMovie(e, req, res) {
	var opts = {
		type : 'movie',
		name : e.name
	};

	client.createEntity(opts, function(err, o) {
		if (err) {
			res.jsonp(500, err);
			return;
		}
		o.set(e);
		o.save(function(err) {
			if (err) {
				res.jsonp(500, err);
				return;
			}
			res.send(201);
		});
	});
}

app.get('/movies?review=true', function(req, res) {	
		getMovies(req, res);
});

function getMoviesWithReview(req,res,next){
    if(req.param('reviews') && req.param('reviews') === 'true'){
    async.parallel([ 


//call the movie first

function(callback) {

var url = "https://api.usergrid.com/quyennguyenmai/HW4/movies" + req.originalUrl;//assuming you just want to pass down the query string

request(url, function (err, response, body) {

// JSON body

if(err) { console.log(err); callback(true); return; }

obj = JSON.parse(body);

callback(false, obj);//callback final

});

},




//query the review with corresponding movie name

function(callback) {

var url = "https://api.usergrid.com/quyennguyenmai/HW4/reviews" + req.originalUrl;

request(url, function (err, response, body) {

// JSON body

if(err) { console.log(err); callback(true); return; }

obj = JSON.parse(body);

callback(false, obj); // callback final

});

},

],
//final callback




function(err, results) {

if(err) { console.log(err); res.send(500,"Severe Error on Server"); return; }

res.send({api1:results[0], api2:results[1]});

console.log(count);

});
}
}

// Listen for requests until the server is stopped

app.listen(process.env.PORT || 9000);
console.log('The server is running!');